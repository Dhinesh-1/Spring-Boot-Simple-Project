package com.example.demo.Service;


import com.example.demo.User;

public interface UserService {


	public User saveUser(User user);

	public User fetchDepartmentById(Long id);

}
